function FigMain=plotStateMPCv3(XUvec,Nk,Tsim,r,tShow,tIni)
% FigMain=plotStateMPC(XUvec,Nk,Tsim,r,tShow,tIni)
% Date: 03-10-2025
% ---------------------------------------------------------------------- %
% Authors: (i) Victor Daniel Reyes Dreke.
% ====================================================================== %
cmap = cool(Nk); 
cNom = 'g';
cMin = cmap(1,:);
cMax = cmap(Nk,:);

timeLine = (0:1:Tsim)';

FigMain = figure();

ax1 = subplot(4,1,1);
ax2 = subplot(4,1,2);
ax3 = subplot(4,1,3);
ax4 = subplot(4,1,4);

for i=1:Nk
    x = [zeros(2,size(XUvec{i,1},2)); XUvec{i,1}];

    if i==1
        % Nominal case
        lnW = 2;
        plot(ax1,timeLine, x(1,:)', 'LineWidth',lnW,...
                                    'Color',cNom,...
                                    'DisplayName', 'nom')
                ylabel(ax1,'$\Delta \iota^{\Delta}_{d}(k)$')
                hold(ax1, "on")
        plot(ax2,timeLine, x(2,:)', 'LineWidth',lnW,...
                                    'Color',cNom,...
                                    'DisplayName', 'nom')
                ylabel(ax2,'$\Delta \iota^{\Delta}_{q}(k)$')
                hold(ax2, "on")  
        plot(ax3,timeLine, x(3,:)', 'LineWidth',lnW,...
                                    'Color',cNom,...
                                    'DisplayName', 'nom')
                ylabel(ax3,'$x_1(k)$')
                hold(ax3, "on")
        plot(ax4,timeLine, x(4,:)', 'LineWidth',lnW,...
                                    'Color',cNom,...
                                    'DisplayName', 'nom')
                ylabel(ax4,'$x_2(k)$')
                hold(ax4, "on")

        % Minimum  value
        xmin =[zeros(2,size(XUvec{2,1},2)); XUvec{2,1}]; %XUvec{2,1};
        plot(ax1,timeLine , xmin(1,:)','LineWidth',3,...
            'Color',cMin,'DisplayName', 'min')
        plot(ax2,timeLine , xmin(2,:)','LineWidth',3,...
            'Color',cMin,'DisplayName', 'min')
        plot(ax3,timeLine , xmin(3,:)','LineWidth',3,...
            'Color',cMin,'DisplayName', 'min')
        plot(ax4,timeLine , xmin(4,:)','LineWidth',3,...
            'Color',cMin,'DisplayName', 'min')
        % Maximum value
        xmax = [zeros(2,size(XUvec{Nk,1},2)); XUvec{Nk,1}]; %XUvec{Nk,1};
        plot(ax1,timeLine , xmax(1,:)','LineWidth',3,...
            'Color',cMax,'DisplayName', 'max')
        plot(ax2,timeLine , xmax(2,:)','LineWidth',3,...
            'Color',cMax,'DisplayName', 'max')
        plot(ax3,timeLine , xmax(3,:)','LineWidth',3,...
            'Color',cMax,'DisplayName', 'max')
        plot(ax4,timeLine , xmax(4,:)','LineWidth',3,...
            'Color',cMax,'DisplayName', 'max')
    else
        plot(ax1,timeLine , x(1,:)','LineWidth',2.5,'Color',cmap(i,:))
        plot(ax2,timeLine , x(2,:)','LineWidth',2.5,'Color',cmap(i,:))
        plot(ax3,timeLine , x(3,:)','LineWidth',2.5,'Color',cmap(i,:))
        plot(ax4,timeLine , x(4,:)','LineWidth',2.5,'Color',cmap(i,:))        

    end
end 

% Final plots 
x = [zeros(2,size(XUvec{1,1},2)); XUvec{1,1}]; %XUvec{1,1};
xmin = [zeros(2,size(XUvec{2,1},2)); XUvec{2,1}]; %XUvec{2,1};
xmax = [zeros(2,size(XUvec{Nk,1},2)); XUvec{Nk,1}]; %XUvec{Nk,1};



lnW =2;
plot(ax1,timeLine , xmin(1,:)','LineWidth',lnW,'Color',cMin)
plot(ax2,timeLine , xmin(2,:)','LineWidth',lnW,'Color',cMin)
plot(ax3,timeLine , xmin(3,:)','LineWidth',lnW,'Color',cMin)
plot(ax4,timeLine , xmin(4,:)','LineWidth',lnW,'Color',cMin)

plot(ax1,timeLine , xmax(1,:)','LineWidth',lnW,'Color',cMax)
plot(ax2,timeLine , xmax(2,:)','LineWidth',lnW,'Color',cMax)
plot(ax3,timeLine , xmax(3,:)','LineWidth',lnW,'Color',cMax)
plot(ax4,timeLine , xmax(4,:)','LineWidth',lnW,'Color',cMax)

plot(ax1,timeLine , x(1,:)','LineWidth',lnW,'Color',cNom)
plot(ax2,timeLine , x(2,:)','LineWidth',lnW,'Color',cNom)
plot(ax3,timeLine , x(3,:)','LineWidth',lnW,'Color',cNom)
plot(ax4,timeLine , x(4,:)','LineWidth',lnW,'Color',cNom)

timeLine = (0:1:Tsim-1)';
stairs(ax3,timeLine , r(1,:)','--k','LineWidth',1.5,'DisplayName', 'ref')
stairs(ax4,timeLine , r(2,:)','--k','LineWidth',1.5,'DisplayName', 'ref')

command_1 = 'colormap(ax1, cool);'; % check autumn
for i=1:4    
    command_1(12) = num2str(i);
    eval(command_1);
end

for i=1:4
    command_2 = "c = colorbar(ax"+string(i)+",'Direction','normal');";
    eval(command_2)
    c.TickLabelInterpreter = 'latex';
    c.Label.Interpreter = 'latex';
    c.Label.String = '$\rho$';
    c.Limits = [0 1];
    c.TickLabels = {'$\rho_{min}$','0','$\rho_{max}$'};
end



 command_expr = 'xlim(ax1, [tIni tShow])';
 for i=1:4     
     command_expr(8) = num2str(i);
     eval(command_expr)
 end

 ylim(ax1,[-0.5 0.3])
 ylim(ax2,[-0.5 0.5])
 ylim(ax3,[-1.1 1.1])
 ylim(ax4,[-0.6 1.1])

 xlabel(ax4, 'Time step $[k]$')

 
 ax1.XMinorGrid = 'on'; ax1.YMinorGrid = 'on';
 ax2.XMinorGrid = 'on'; ax2.YMinorGrid = 'on';
 ax3.XMinorGrid = 'on'; ax3.YMinorGrid = 'on';
 ax4.XMinorGrid = 'on'; ax4.YMinorGrid = 'on';



  legend(ax4,{'$\rho =0_4$',...
     '$\rho =-0.4 \cdot 1_{4}$',...
     '$\rho =0.4 \cdot 1_{4}$'},...
     'Location','southwest', 'Orientation','vertical')
end