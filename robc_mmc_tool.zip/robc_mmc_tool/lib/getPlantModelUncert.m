function [A,B,C,ssMat] = getPlantModelUncert(Rm, Rg, Lm, Lg, w,...
                                         dRm, dRg, dLm, dLg, dw, type)
% getPlantModelUncert(Rm, Rg, Lm, Lg, w, dRm, dRg, dLm, dLg, dw, type) 
% generates the A,B,C matrices corresponding to continous-time state-space
% realization of the  MMC model,  i.e., x(k+1) = Ax(k) + Bu(k),
% where A =(A0+dA), B=(B0+dB).
% ---------------------------------------------------------------------- %
% Inputs: 
%  Rm    ->     [Ohm] arm resistance
%  Rg    ->     [Ohm] grid resistance
%  Lm    ->     [Ohm] arm inductance
%  Lg    ->     [Ohm] grid inductance
%  type  ->     [string] defines the type of model to be used.
% ---------------------------------------------------------------------- %
% Outputs:
% A     ->      [matrix] state matrix
% B     ->      [matrix] input matrix
% C     ->      [matrix] output matrix 
% ---------------------------------------------------------------------- %
% Authors: (i) Msc. Rahul Rane, (ii) Victor Daniel Reyes Dreke.
% ====================================================================== %

% dw = 0; % it is set to zero because I frequency is assumed to be constant

if nargin>=10
    % OCC model
        warning('The default type model, i.e., OCC, is used.')
        % AC side equivalent parameters
        Delta_R = dRg + dRm/2;
        Delta_L = dLg + dLm/2;

        R_ac_eq = Rg + Rm/2;
        L_ac_eq = Lg + Lm/2;
    
        % Continuous-time state-space model (Nominal)
        A0 = [-R_ac_eq/L_ac_eq, -w; w, -R_ac_eq/L_ac_eq];
        B0 = [1/L_ac_eq, 0; 0, 1/L_ac_eq];
        

        % Continuous-time state-space model (Uncertaint)
        adelta = (Delta_R*L_ac_eq-R_ac_eq*Delta_L)/...
                    (L_ac_eq*(L_ac_eq+Delta_L));
        bdelta = (-Delta_L)/(L_ac_eq*(L_ac_eq+Delta_L));

        Delta_A = eye(2)*adelta;
        Delta_B = eye(2)*bdelta;

        C = eye(2);
        A = A0 - Delta_A; % why is negative???
        B = B0 + Delta_B;

        ssMat.A0 = A0;
        ssMat.B0 = B0;
        ssMat.Delta_A = Delta_A;
        ssMat.Delta_B = Delta_B;

        warning('The default type model, i.e., OCC, is used.')
else
        error('Check the input parameters for the function getPlantModelUncert.')

end

if nargin>=11
        type = string(type);
        if type == "occ"

            % C = eye(2);
            % A = A0 - Delta_A; % why is negative???
            % B = B0 + Delta_B;
            % 
            % ssMat.A0 = A0;
            % ssMat.B0 = B0;
            % ssMat.Delta_A = Delta_A;
            % ssMat.Delta_B = Delta_B;
            disp("OCC Model used.\n --------------")

        elseif type == "ccc"

            % Continuous-time state-space model (Nominal)
            A0 = [-(Rm)/(Lm), 2*w; -2*w, -(Rm)/(Lm)];
            B0 = [-1/(Lm), 0; 0, -1/(Lm)];
            C0 = eye(2);

            % Continuous-time state-space model (Uncertaint)
            asigma = (dRm*Lm-Rm*dLm)/...
                        (Lm*(Lm+dLm));
            bsigma = (-dLm)/(Lm*(Lm+dLm));
    
            Delta_A = eye(2)*asigma;
            Delta_B = eye(2)*bsigma;

        elseif type == "zcc"
            % Continuous-time state-space model
            A = -(Rm+ dRm)/(Lm+ dLm);
            B = -1/(Lm+ dLm);
            C = 1;
        else
            warning('The default type model, i.e., OCC, is used.')
            % AC side equivalent parameters
            % Delta_R = dRg + dRm/2;
            % Delta_L = dLg + dLm/2;
            % 
            % R_ac_eq = Rg + Rm/2 + Delta_R;
            % L_ac_eq = Lg + Lm/2 + Delta_L;
            % 
            % % Continuous-time state-space model
            % A = [-R_ac_eq/L_ac_eq, -w; w, -R_ac_eq/L_ac_eq];
            % B = [1/L_ac_eq, 0; 0, 1/L_ac_eq];
            % C = eye(2);
        end
end

C = eye(2);
A = A0 - Delta_A; % why is negative???
B = B0 + Delta_B;
    
ssMat.A0 = A0;
ssMat.B0 = B0;
ssMat.Delta_A = Delta_A;
ssMat.Delta_B = Delta_B;

end
